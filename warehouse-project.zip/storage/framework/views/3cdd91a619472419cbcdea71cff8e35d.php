<div>
    <div class="grid grid-cols-2 justify-center">
        <div id="wm"></div>
        <div id="tp"></div>
        <div id="rt"></div>
        <div id="ms"></div>
        <div id="inf"></div>
    </div>
    <script src="<?php echo e(asset('chart/dist/apexcharts.min.js')); ?>"></script>
    <script>
        var options1 = {
                series: [
                    {
                        name: 'PLAN (Liter)',
                        data: <?php echo json_encode($chart_wm_plan, 15, 512) ?>,
                    },
                    {
                        name: 'REAL (Liter)',
                        data: <?php echo json_encode($chart_wm_real, 15, 512) ?>,
                    },
                    {
                        name: 'ACH (Liter)',
                        data: <?php echo json_encode($chart_wm_ach, 15, 512) ?>,
                    },
                ],
                chart: {
                    type: 'bar',
                    height: 300,
                    width: '100%',
                    toolbar:
                        {
                            show: false
                        },
                },
                plotOptions: {
                    bar: {
                        horizontal: false,
                        columnWidth: '100%',
                        endingShape: 'rounded',
                    },
                },
                dataLabels: {
                    enabled: false,
                }
                ,
                stroke: {
                    show: true,
                    width:
                        5,
                    colors:
                        ['transparent']
                }
                ,
                xaxis: {
                    categories: ['QUALITY'],
                },
                fill: {
                    opacity: 1
                },
                yaxis: {
                    labels: {
                        formatter: function (value) {
                            return value.toFixed(2);
                        }
                    }
                    ,
                },
                title: {
                    text: 'WATER MANAGEMENT SYSTEM',
                }
                ,
                tooltip: {
                    y: {
                        formatter: function (val) {
                            return val + " Liter"
                        }
                    }
                }
            }
        ;
        var chart = new ApexCharts(document.querySelector("#wm"), options1);
        chart.render();


        // Transport Panen Chart
        var options2 = {
            series: [
                {
                    name: 'PLAN',
                    data: <?php echo json_encode($chart_tp_plan, 15, 512) ?>,
                },
                {
                    name: 'REAL (Liter)',
                    data: <?php echo json_encode($chart_tp_real, 15, 512) ?>,
                },
                {
                    name: 'ACH (Liter)',
                    data: <?php echo json_encode($chart_tp_ach, 15, 512) ?>,
                },
            ],
            chart: {
                type: 'bar',
                height: 300,
                toolbar: {
                    show: false
                }
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '100%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                show: true,
                width: 5,
                colors: ['transparent']
            },
            xaxis: {
                categories: ['QUALITY'],
            },
            yaxis: {
                labels: {
                    formatter: function (value) {
                        return value.toFixed(2);
                    }
                },
            },
            title: {
                text: 'TRANSPORT'
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return val + " Liter"
                    }
                }
            }
        };
        var chart = new ApexCharts(document.querySelector("#tp"), options2);
        chart.render();

        //     Rawat TM Chart
        var options3 = {
            series: [
                {
                    name: 'PLAN (Liter)',
                    data: <?php echo json_encode($chart_rt_plan, 15, 512) ?>,
                },
                {
                    name: 'REAL (Liter)',
                    data: <?php echo json_encode($chart_rt_real, 15, 512) ?>,
                },
                {
                    name: 'ACH (Liter)',
                    data: <?php echo json_encode($chart_rt_ach, 15, 512) ?>,
                },
            ],
            chart: {
                type: 'bar',
                height: 300,
                toolbar: {
                    show: false
                }
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '100%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                show: true,
                width: 5,
                colors: ['transparent']
            },
            xaxis: {
                categories: ['QUALITY',],

            },
            yaxis: {
                labels: {
                    formatter: function (value) {
                        return value.toFixed(2);
                    }
                },
            },
            title: {
                text: 'RAWAT'
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return val + " Liter"
                    }
                }
            }
        };
        var chart = new ApexCharts(document.querySelector("#rt"), options3);
        chart.render();

        // Mills Support Chart
        var options4 = {
            series: [
                {
                    name: 'PLAN (Liter)',
                    data: <?php echo json_encode($chart_ms_plan, 15, 512) ?>,
                },
                {
                    name: 'REAL (Liter)',
                    data: <?php echo json_encode($chart_ms_real, 15, 512) ?>,
                },
                {
                    name: 'ACH (Liter)',
                    data: <?php echo json_encode($chart_ms_ach, 15, 512) ?>,
                },
            ],
            chart: {
                type: 'bar',
                height: 300,
                toolbar: {
                    show: false
                }
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '100%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                show: true,
                width: 5,
                colors: ['transparent']
            },
            xaxis: {
                categories: ['QUALITY'],
            },
            yaxis: {
                labels: {
                    formatter: function (value) {
                        return value.toFixed(2);
                    }
                },
            },
            title: {
                text: 'PABRIK'
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return val + " Liter"
                    }
                }
            }
        };
        var chart = new ApexCharts(document.querySelector("#ms"), options4);
        chart.render();

        // Infrastructur Chart
        var options5 = {
            series: [
                {
                    name: 'PLAN (Liter)',
                    data: <?php echo json_encode($chart_inf_plan, 15, 512) ?>,
                },
                {
                    name: 'REAL (Liter)',
                    data: <?php echo json_encode($chart_inf_real, 15, 512) ?>,
                },
                {
                    name: 'ACH (Liter)',
                    data: <?php echo json_encode($chart_inf_ach, 15, 512) ?>,
                },
            ],
            chart: {
                type: 'bar',
                height: 300,
                toolbar: {
                    show: false
                }
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '100%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                show: true,
                width: 5,
                colors: ['transparent']
            },
            xaxis: {
                categories: ['QUALITY'],
            },
            yaxis: {
                labels: {
                    formatter: function (value) {
                        return value.toFixed(2);
                    }
                },
            },
            title: {
                text: 'TEKNIK'
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return val + " Liter"
                    }
                }
            }
        };
        var chart = new ApexCharts(document.querySelector("#inf"), options5);
        chart.render();
    </script>
</div>





<?php /**PATH C:\Users\kelvi\OneDrive\Documents\FLUTTER DEV\warehouse-project\resources\views/livewire/solar/solar-chart.blade.php ENDPATH**/ ?>