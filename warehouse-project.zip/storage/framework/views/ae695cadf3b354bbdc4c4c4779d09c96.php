<svg class="size-5" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path d="M14 11h1a2 2 0 0 1 2 2v3a1.5 1.5 0 0 0 3 0v-7l-3 -3" />
  <path d="M4 20v-14a2 2 0 0 1 2 -2h6a2 2 0 0 1 2 2v14" />
  <path d="M3 20l12 0" />
  <path d="M18 7v1a1 1 0 0 0 1 1h1" />
  <path d="M4 11l10 0" />
</svg><?php /**PATH C:\Users\kelvi\OneDrive\Documents\FLUTTER DEV\warehouse-project\storage\framework\views/e4b4486842c3e08dcb559714b5bae3f0.blade.php ENDPATH**/ ?>